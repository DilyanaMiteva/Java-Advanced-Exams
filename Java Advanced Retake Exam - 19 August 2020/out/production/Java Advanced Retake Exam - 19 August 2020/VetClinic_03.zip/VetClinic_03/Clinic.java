package VetClinic_03;

import java.util.*;

public class Clinic {
    private List<Pet> pets;
    private int capacity;

    public Clinic(int capacity) {
        this.pets = new ArrayList<>();
        this.capacity = capacity;
    }

    public List<Pet> getPets() {
        return pets;
    }

    public void setPets(List<Pet> pets) {
        this.pets = pets;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void add(Pet pet) {
        if (this.pets.size() < capacity) {
            this.pets.add(pet);
        }
    }

    public boolean remove(String name){
        return this.pets.removeIf(e -> e.getName().equals(name));
    }

    public Pet getPet(String name, String owner){
        return this.pets.stream().filter(e -> e.getName().equals(name) && e.getOwner().equals(owner)).findFirst().orElse(null);
    }

    public Pet getOldestPet() {
        return this.pets.stream().min((p1, p2) -> Integer.compare(p2.getAge(), p1.getAge())).orElse(null);
    }

    public int getCount() {
        return this.pets.size();
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder("The clinic has the following patients:");
        sb.append(System.lineSeparator());
        pets.forEach(e -> sb.append(e.getName()).append(" ").append(e.getOwner()).append(System.lineSeparator()));
        return sb.toString();
    }
}
